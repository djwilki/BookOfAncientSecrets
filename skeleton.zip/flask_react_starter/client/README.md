This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

# Running The Frontend in Development
1. Run `npm install`.
2. Install other dependencies
3. Run this application using `npm start`.

Please see the README in the root of your project skeleton for information about deployment.

### Navigation
* [Back to root README](../README.md)