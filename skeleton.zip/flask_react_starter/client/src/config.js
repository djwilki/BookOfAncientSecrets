export const baseUrl = '';
export const imageUrl = `${baseUrl}/`;
